package tests

import org.scalatest.FunSuite
import expressions.Expressions._

class TestRunScript extends FunSuite{
  val EPSILON: Double = 0.000001

  def equalDoubles(d1: Double, d2: Double): Boolean = {
    (d1 - d2).abs < EPSILON
  }

  test("test RunScript"){
    val filename = "data/file.txt"

    val pow = (a: Double, b: Double) => Math.pow(a, b)
    val mul = (a: Double, b: Double) => a * b
    val div = (a: Double, b: Double) => a / b
    val add = (a: Double, b: Double) => a + b
    val sub = (a: Double, b: Double) => a - b

    val operatorTable: Map[String, (Double, Double) => Double] = Map(
      "^" -> pow,
      "*" -> mul,
      "/" -> div,
      "+" -> add,
      "-" -> sub
    )

    val order = List(List("^"), List("*", "/"), List("+", "-"))

    assert(equalDoubles(runScript(filename, (s: String) => s.toDouble, operatorTable, order), 81.0))
  }
}
